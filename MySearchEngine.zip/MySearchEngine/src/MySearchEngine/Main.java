package MySearchEngine;


import java.io.IOException;



class Main {

	public static void main(String[] args) throws IOException {
		
		//Creates the GUI window , all functionality  
		GUI Frame = new GUI("My Search Engine");
		
	

	} //end main method

}//end class main
