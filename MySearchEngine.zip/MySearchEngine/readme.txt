My project is a search engine.

It takes a keyword from a GUI , searches through a folder of text files , and returns
an ordered list of what text docs have the most matches with the search term

The text source I decided to use is a text version of the Java API documentation, 
functions from the IO , SQL and Text folders are inclused in the text source

My Project has 5 classes

Main - Where the GUI class is called 

GUI - Displays the GUI , Gets the search term from the user. Displays results of the search 

Search - Breakes a text file down into lines and then words , compares each word to the search
	 term, returns a count of how many times the search term appears in the text doc

FolderSearch - Finds the path of the text source on the users computer. 
		Cycles through each file that needs to be searched

RankResults - Puts the results of the search into a LinkedHashMap , calls for the 
	      results to be compared and put into a TreeMap that will be returned 
	      to the GUI
CompareResults- Compares the values from the LinkedHashMap and determines what value
		is greater

https://youtu.be/LkV-2t3B8Fk
